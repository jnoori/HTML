function portfolioPage(){
	window.location="html/portfolio.html";
}