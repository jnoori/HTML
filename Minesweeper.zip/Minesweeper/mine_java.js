﻿var end_t=0; //بعد از برنده/بازنده شدن رویداد کلیک و راست کلیک کار نکند
var tm=0; //تابع تایمر را در رویداد کلیک فقط دفعه اول فراخوانی شود
var stop; //متوقف ساخت تایمر

function time(){ //تابع تایمر
	stop=setInterval(function(){
	var t = $('.input1').val() * 1 + 1;
	$('.input1').val(t)
	},1000);
}

function end_game(){ //تابع باخت
	if(end_t==1){
		alert('you lose');
	}
	return true;
}//end function
	
$(function (){
	
	array = new Array(9);
	str=new Array(9);
	for(var i=0;i<9;i++){
		array[i]=new Array(9);
		str[i]=new Array(9);
		for(var j=0;j<9;j++){
			array[i][j]=0;
			str[i][j]=0;
		}
	}
	$('.square_number').hide();

	var sq_num;//number of div when we are in click event
	var a;
	var b;
	var kx;// for get this
	var kx2;
	var mine_num=10; 
	var i=0;
	var j=0;
	var index1;
	var ch=71; //اگر صفر شود شخص برنده بازی است
	var start=0;// flag for starting game and prevent to set bombs several
	
	function remove_class(th){
		$(th).removeClass('under');
		$(th).removeClass('front');
		$(th).removeClass('under_q');
		$(th).removeClass('q_mark');
	}
	
	function seprate(num){
		j=(num%10)*1;
		i=(num-j)/10;
		return true;
	}	
	
	function array_index(p,q){ //تابعی که ایندکس آرایه را با استفاده از محل هر عنصر مشخص می کند
		var tmp=p*10+q;
			if(p==0){
				index1=q;
			}
			else if(p==1){
				index1=tmp-1;
			}
			else if(p==2){
				index1=tmp-2;
			}
			else if(p==3){
				index1=tmp-3;
			}
			else if(p==4){
				index1=tmp-4;
			}
			else if(p==5){
				index1=tmp-5;
			}
			else if(p==6){
				index1=tmp-6;
			}
			else if(p==7){
				index1=tmp-7;
			}else if(p==8){
				index1=tmp-8;
			}
		return true;
	}//end function array_index

	var k1;
	var k2;
	var k3;
	var k4;
	function var_k(a1,b1){ //متغیر های جستجوی خانه های اطراف بمب ها و اعداد را مشخص می کند
		k1=k2=a1;
		k3=k4=b1;
			if(a1== 0){
				k2=1;
			}
			else if(a1==8){
				k1=a1-1;
			}
			else{
				k1=a1-1;
				k2=a1+1;
			}
			if(b1== 0){
				k4=1;
			}
			else if(b1==8){
				k3=b1-1;
			}
			else{
				k3=b1-1;
				k4=b1+1;
			}
	}//end function var_k

	$('div.block').addClass('under');
	$('div.block').addClass('front');
	$('div.front'). hover(function(){ //hover event
		if($(this).hasClass('front')){ 
			$(this).removeClass('front');
		}
		else if($(this).hasClass('flag')){
			$(this).removeClass('flag');
		}
		else if($(this).hasClass('q_mark')){
			$(this).removeClass('q_mark');
		}
	},function(){
		if($(this).hasClass('under')){
			$(this).addClass('front');
		}
		else if($(this).hasClass('under_flag')){
			$(this).addClass('flag');
		}
		else if($(this).hasClass('under_q')){
			$(this).addClass('q_mark');
		}
	});//end hover event
	
	$('div.block').bind("contextmenu", function(e) { //right click function
		e.preventDefault();
		if(end_t==0){
			if($(this).hasClass('under')){
				$(this).removeClass('under');
				$(this).removeClass('front');
				$(this).addClass('under_flag');
				mine_num-=1;
				$('.input2').val(mine_num);
			}
			else if($(this).hasClass('under_flag')){
				$(this).removeClass('under_flag');
				$(this).removeClass('flag');
				$(this).addClass('under_q');
				mine_num+=1;
				$('.input2').val(mine_num);
			}
			else if($(this).hasClass('under_q')){
				$(this).removeClass('under_q');
				$(this).removeClass('q_mark');
				$(this).addClass('under');
			}
		}
	});//end right click event
	
	var chk=function(x){ //تابعی که در رویداد کلیک فراخوانی می شود
		if($(x).hasClass('under') || $(x).hasClass('under_q')
			||$(x).hasClass('front')||$(x).hasClass('q_mark')){
			if(tm==0){ //تابع تایمر را در اولین کلیک فراخوانی می کند
				$('.input1').val(1);
				tm=1;
				time();
			}
			seprate(sq_num);
			if(array[i][j]!= 'm' && array[i][j]!= 'choise'){
				var square_number=array[i][j];
				if(square_number==0){//اگر خانه کلیک شده صفر بود 
								//تمام خانه های اطراف آن باز می شود
					array[i][j]='choise';//برای اینکه خانه باز شده 
									//دوباره عدد جدید دریافت نکند
					ch--;
					remove_class(x);
					$(x).addClass('empty');
					var x1=i;
					var x2=i;
					var y1=j;
					var y2=j;
				
					if(i==0){
						x2=1;
					}
					else if(i==8){
						x1=7;
					}
					else{
						x1=i-1;
						x2=i+1;
					}
					if(j==0){
						y2=1;
					}
					else if(j==8){
						y1=7;
					}
					else{
						y1=j-1;
						y2=j+1;
					}
					a=i;
					b=j;
					
					for(var i1=x1;i1<=x2;i1++){
						for(var j1=y1;j1<=y2;j1++){
							if(array[i1][j1]!='m' && (i1*10+j1)!=(a*10+b)){  
								array_index(i1,j1);
								if(array[i1][j1]==1){
									//array[i1][j1]='choise';
									$('.block').each(function(index){
										if((index==index1) && ($(this).hasClass('front')
											||$(this).hasClass('under') ||$(this).hasClass('q_mark')
											||$(this).hasClass('under_q'))){
												ch--;
												kx2=this;
												remove_class(kx2);
												$(this).addClass('num_1');
												array[i1][j1]='choise';
										}
									});
								}
								else if(array[i1][j1]==2){
									array[i1][j1]='choise';
									$('.block').each(function(index){
										if((index==index1) && ($(this).hasClass('front')
											||$(this).hasClass('under') ||$(this).hasClass('q_mark')
											||$(this).hasClass('under_q'))){
											ch--;
											kx2=this;
											remove_class(kx2);
											$(this).addClass('num_2');
											array[i1][j1]='choise';
										}
									});
								}
								else if(array[i1][j1]==3){
									array[i1][j1]='choise';
									$('.block').each(function(index){
										if((index==index1) && ($(this).hasClass('front')
											||$(this).hasClass('under') ||$(this).hasClass('q_mark')
											||$(this).hasClass('under_q'))){
												ch--;
												kx2=this;																								remove_class(kx2);
												$(this).addClass('num_3');
												array[i1][j1]='choise';
										}
									});
								}
								else if(array[i1][j1]==4){
									array[i1][j1]='choise';
									$('.block').each(function(index){
										if((index==index1) && ($(this).hasClass('front')
											||$(this).hasClass('under') ||$(this).hasClass('q_mark')
											||$(this).hasClass('under_q'))){
												ch--;
												kx2=this;
												remove_class(kx2);
												$(this).addClass('num_4');
												array[i1][j1]='choise';
										}
									});
								}
								else if(array[i1][j1]==5){
									array[i1][j1]='choise';
									$('.block').each(function(index){
										if((index==index1) && ($(this).hasClass('front')
											||$(this).hasClass('under') ||$(this).hasClass('q_mark')
											||$(this).hasClass('under_q'))){
												ch--;
												kx2=this;
												remove_class(kx2);
												$(this).addClass('num_5');
												array[i1][j1]='choise';
										}
									});
								}
								else if(array[i1][j1]==6){
									array[i1][j1]='choise';
									$('.block').each(function(index){
										if((index==index1) && ($(this).hasClass('front')
											||$(this).hasClass('under') ||$(this).hasClass('q_mark')
											||$(this).hasClass('under_q'))){
												ch--;
												kx2=this;
												remove_class(kx2);
												$(this).addClass('num_6');
												array[i1][j1]='choise';
										}
									});
								}
								else if(array[i1][j1]==7){
									array[i1][j1]='choise';
									$('.block').each(function(index){
										if((index==index1) && ($(this).hasClass('front')
											||$(this).hasClass('under') ||$(this).hasClass('q_mark')
											||$(this).hasClass('under_q'))){
												ch--;
												kx2=this;
												remove_class(kx2);
												$(this).addClass('num_7');
												array[i1][j1]='choise';
										}
									});
								}
								else if(array[i1][j1]==8){
									array[i1][j1]='choise';
									$('.block').each(function(index){
										if((index==index1) && ($(this).hasClass('front')
											||$(this).hasClass('under') ||$(this).hasClass('q_mark')
											||$(this).hasClass('under_q'))){
												ch--;
												kx2=this;
												remove_class(kx2);
												$(this).addClass('num_8');
												array[i1][j1]='choise';
										}
									});
								}
								else{
									$('.block').each(function(index){
										if(index==index1){
											sq_num=(i1*10)+j1;
											kx=this;
											chk(kx);
										}
									});
								}
								
							}//end if(array..)
						}//end for(i...)
					}//end for(j...)
				}//end if(square_number==0)
				else if(square_number==1){
					array[i][j]='choise';
					ch--;
					remove_class(x);
					$(x).addClass('num_1');
				}
				else if(square_number==2){
					array[i][j]='choise';
					ch--;
					remove_class(x);
					$(x).addClass('num_2');
				}
				else if(square_number==3){
					array[i][j]='choise';
					ch--;
					remove_class(x);
					$(x).addClass('num_3');
				}
				else if(square_number==4){
					array[i][j]='choise';
					ch--;
					remove_class(x);
					$(x).addClass('num_4');
				}
				else if(square_number==5){
					array[i][j]='choise';
					ch--;
					remove_class(x);
					$(x).addClass('num_5');
				}
				else if(square_number==6){
					array[i][j]='choise';
					ch--;
					remove_class(x);
					$(x).addClass('num_6');
				}
				else if(square_number==7){
					array[i][j]='choise';
					ch--;
					remove_class(x);
					$(x).addClass('num_7');
				}
				else if(square_number==8){
					array[i][j]='choise';
					ch--;
					remove_class(x);
					$(x).addClass('num_8');
				}
				
			}//end if(array!='m'...)
			else if(array[i][j]== 'm'){ //چک کردن بازنده
				array[i][j]='m_lose';
					remove_class(x);
				$(x).addClass('explode');
				$('.block').each(function(index){ //پرچم های غلط را مشخص می کند
					if($(this).hasClass('flag')||
						$(this).hasClass('under_flag')){
							sq_num=$(this).text();
							seprate(sq_num);
							if(array[i][j]!='m'){
								$(this).removeClass('under_flag');
								$(this).removeClass('flag');
								$(this).addClass('flag_wrong');
							}
					}
				});
				for(var i1=0;i1<=8;i1++){ //نشان دادن مکان بمب ها
					for(var j1=0;j1<=8;j1++){
						if(array[i1][j1]=='m'){  
							array_index(i1,j1);
							$('.block').each(function(index){
								if((index==index1)&& ($(this).hasClass('under')||
									$(this).hasClass('under_q') ||
									$(this).hasClass('front') ||
									$(this).hasClass('q_mark'))){
										kx2=this;
										remove_class(kx2);
										$(this).addClass('mine_lose');
								}
							});
						}
					}
				}
				end_t=1;
				clearInterval(stop);
				end_game();
				return false;
			}
		}//end if($(x)...)
		if(ch==0){ //چک کردن برنده بازی
			ch=1;
			$('.input2').val(0);
			end_t=1;
			clearInterval(stop);
			$('.block').each(function(index){
				if($(this).hasClass('under')||$(this).hasClass('under_q')){
					kx2=this;
					remove_class(kx2);
					$(this).addClass('win');
				}
			});
			alert('you win');
			return false;
		}//end if(ch==0)
	}//end chk() function
	
	function setup_value(){ //to start game and setting bombs
			start=1;
			var num=0;
			start=1;
			var st;
			seprate(sq_num);
			if(((i*j)!=0) && i!=8 && j!=8){
				st=Math.round(Math.random()*8);
			}
			else if((i==0 && j==0) || (i==0 && j==8) //اگر چهار گوشه اطراف انتخاب شوند
					|| (i==8 && j==0)|| (i==8 && j==8)){
					st=Math.round(Math.random()*3);
			}
			else if((i==0 && j>0) || (j==0 && i>0)
					|| (i==8 && j>0)|| (j==8 && j>0)){
					st=Math.round(Math.random()*5);
			}
			array[i][j]=st;
			str[i][j]='cn' //عدد تصادفی اولیه تغییر نکند
			num+=st;
			var_k(i,j);
			if(st==0){ //اگر عدد تصادفی انتخاب شده ابتدای بازی صفر باشد
				for(var i1=k1;i1<=k2;i1++){
					for(var j1=k3;j1<=k4;j1++){
						if(i1!=i && j1!=j){
							str[i1][j1]='cn';
						}
					}
				}
			}
			else{
				while(st!=0){ //قرار دادن بمب های اطراف عدد اولیه
					a=Math.round(Math.random()*2+(i-1)); // گرد کردن عدد اعشاری
					b=Math.round(Math.random()*2+(j-1));;
					if( (a*10+b)!=(i*10+j) && (a>=0 && a<=8) && (b>=0 && b<=8)){
						if(array[a][b]!='m'){
							st--;
							var_k(a,b);
							array[a][b]='m';						
							for(var i1=k1;i1<=k2;i1++){//اعداد اطراف بمب را تعیین میکند
								for(var j1=k3;j1<=k4;j1++){
									if(array[i1][j1]!='m' && (i1*10+j1)!=(i*10+j)){
										array[i1][j1]+=1;
										str[i1][j1]='cn';
									}
								}
							}
						}
					}
				}//end while
			}//end else
			while(num<10){//چیدمان بقیه بمب ها را انجام می دهد
				a=Math.round(Math.random()*8);
				b=Math.round(Math.random()*8);
				var_k(a,b);
				if((array[a][b]!='m')&&(str[a][b]!='cn')){//خانه های اطراف عدد اولیه نباید انتخاب شود
					array[a][b]='m';
					num++;
					for(var i1=k1;i1<=k2;i1++){
						for(var j1=k3;j1<=k4;j1++){
							if(array[i1][j1]!='m'){  
								array[i1][j1]+=1;
							}
						}
					}
				}
			}//end while
			chk(kx);
			return true;
	} //end setup_value function
	
	$('div.block').click(function(){ //click event
		kx=this;
		sq_num=$(this).text();
		if(start==0){
			setup_value();
		}
		else if(($(this).hasClass('under') || $(this).hasClass('under_q')
			||$(this).hasClass('front')||$(this).hasClass('q_mark'))&& (end_t==0)
				&& start!=0){
			chk(kx);
		}
	});//end click event
});