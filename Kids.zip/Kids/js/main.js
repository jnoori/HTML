var qNum;
var answerNum;
function welcome(){
	var person = prompt("Please enter your name");
	if (person != null) {
	  window.location.href="crossword.html"
	  alert("Hello "+person+" lets play crossword!!!");
	}
}
function fToC() {
	let f= parseFloat(document.getElementById("fToC").value);
	let fTemp = f;
	let fToCel = Math.round((fTemp - 32) * 5 / 9);
	let message = fTemp+'\xB0F is ' + fToCel + '\xB0C.';
 	document.getElementById("convertResult").innerHTML=message;
}
function checkAnswer(){
	let id=document.getElementsByClassName("javadQuestions")[0].id;
}
function getAnswer(clickedId, parentId){
	alert(parentId);
}
























































console.log("Delete line 12, close the comment on line 7");
console.log("The images shlould be inside the image folder");
console.log("the Path of the images are correct? the name of the image is corret too?")
console.log("I Think your Css is not linked properly.")