var answerNum=[];
for(var i=0; i<2; i++){
	answerNum[i]=0;
}
function welcome(){
	var person = prompt("Please enter your name");
	if (person != null) {
	  window.location.href="crossword.html"
	  alert("Hello "+person+" let's play crossword!!!");
	}
}
function fToC() {
	if(document.getElementById("fToC").value != ""){
		let f= parseFloat(document.getElementById("fToC").value);
		let fTemp = f;
		let fToCel = Math.round((fTemp - 32) * 5 / 9);
		let message = fTemp+'\xB0F is ' + fToCel + '\xB0C.';
 		document.getElementById("convertResult").innerHTML=message;
	}
	
}
function getAnswer(clickedId, parentId){
	if(parentId == "q1"){
		if(clickedId=="q1a1"){
			answerNum[0]=1;
		}else if(clickedId=="q1a2"){
			answerNum[0]=2;
		}else if(clickedId=="q1a3"){
			answerNum[0]=3;
		}
	}else if(parentId == "q2"){
		if(clickedId=="q2a1"){
			answerNum[1]=1;
		}else if(clickedId=="q2a2"){
			answerNum[1]=2;
		}else if(clickedId=="q2a3"){
			answerNum[1]=3;
		}
	}
}
function checkAnswer(){
	if(answerNum[0]==1){
		//document.getElementById("lq1a1").style.backgroundColor = "green";
		document.getElementById("lq1a1").className += "green";
	}else if(answerNum[0]==2){
		document.getElementById("lq1a2").className += "red";
	}else if(answerNum[0]==3){
		document.getElementById("lq1a3").className += "red";
	}
	if(answerNum[1]==1){
		document.getElementById("lq2a1").className += "red";
	}else if(answerNum[1]==2){
		document.getElementById("lq2a2").className += "green";
	}else if(answerNum[1]==3){
		document.getElementById("lq2a3").className += "red";
	}
	document.getElementById("showResult").disabled = true;
}
function checkAge(){
	let age= document.getElementById("inputAge").value;
	if(age != ""){
		if(age<0){
		alert("you’re kidding, right?");
		}else if(age==0){
			alert("oh Baby, how can you work with computer that early in life")
		}else if(age>100){
			alert("you are too old to play!");
		}else{
			alert("your are "+age+" years old");
		}
	}
	
}
function checkEvenOdd(){
	let number= document.getElementById("inputEvenOdd").value;
	if(number != ""){
		if(number%2 ==0){
			alert("Even");
		}else{
			alert("Odd");
		}
	}
}

























































console.log("Delete line 12, close the comment on line 7");
console.log("The images shlould be inside the image folder");
console.log("the Path of the images are correct? the name of the image is corret too?")
console.log("I Think your Css is not linked properly.")