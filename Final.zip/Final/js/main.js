var answerNum=[];
for(var i=0; i<2; i++){
	answerNum[i]=0;
}
function fToC() {
	if(document.getElementById("fToC").value != ""){
		let f= parseFloat(document.getElementById("fToC").value);
		let fTemp = f;
		let fToCel = Math.round((fTemp - 32) * 5 / 9);
		let message = fTemp+'\xB0F is ' + fToCel + '\xB0C.';
 		document.getElementById("convertResult").innerHTML=message;
 		if(fToCel < 0){
 			alert("“It’s freezing!");
 		}else if(fToCel>30){
 			alert("It’s too hot!");
 		}
 	}
}
function getAnswer(clickedId, parentId){
	if(parentId == "q1"){
		if(clickedId=="q1a1"){
			answerNum[0]=1;
		}else if(clickedId=="q1a2"){
			answerNum[0]=2;
		}else if(clickedId=="q1a3"){
			answerNum[0]=3;
		}
	}else if(parentId == "q2"){
		if(clickedId=="q2a1"){
			answerNum[1]=1;
		}else if(clickedId=="q2a2"){
			answerNum[1]=2;
		}else if(clickedId=="q2a3"){
			answerNum[1]=3;
		}
	}
}
function checkAnswer(){
	let result=0;
	let answer1="The answer is Honey";
	let answer2="The answer is Australia";
	document.getElementById("q1Answer").innerHTML=answer1;
	document.getElementById("q2Answer").innerHTML=answer2;
	if(answerNum[0]==1){
		document.getElementById("lq1a1").className += "green";
		result++;
	}else if(answerNum[0]==2){
		document.getElementById("lq1a2").className += "red";
	}else if(answerNum[0]==3){
		document.getElementById("lq1a3").className += "red";
	}
	if(answerNum[1]==1){
		document.getElementById("lq2a1").className += "red";
	}else if(answerNum[1]==2){
		document.getElementById("lq2a2").className += "green";
		result++;
	}else if(answerNum[1]==3){
		document.getElementById("lq2a3").className += "red";
	}
	document.getElementById("showResult").disabled = true;
	if(result == 2){
		alert("You made it, 2 of 2!");
	}else if(result == 1){
		alert("1 of 2! Good job.");
	}else{
		alert("You should study more!");
	}
}

function geoCalc(){
	let totalHour=0;
	let rate=0;
	let overTime=0;
	let grossIncome=0;
	let salary=0;
	let CPP=0;
	let cppRate=4.95;
	let EI=0;
	let EIrate=1.7;
	if(document.getElementById("totalHour").value != ""
		&& document.getElementById("rate").value != ""){
		let totalHour= parseFloat(document.getElementById("totalHour").value);
		let rate= parseFloat(document.getElementById("rate").value);
		if(totalHour>0 && rate>0){
			if(totalHour > 40){
			overTime = totalHour-40;
			grossIncome = 40*rate +(overTime*(rate+(rate*20/100)));
			CPP= grossIncome*cppRate/100;
			EI= grossIncome*EIrate/100;
			salary=grossIncome-CPP-EI;
			}else{
				grossIncome= totalHour*rate;
				CPP= grossIncome*cppRate/100;
				EI= grossIncome*EIrate/100;
				salary=grossIncome-CPP-EI;
			}
			let message = "the gross income is $"+grossIncome.toFixed(2)+"</br>"+
							"TAX:"+"</br>"+
							"CPP $"+CPP.toFixed(2)+"</br>"+
							"EI $"+EI.toFixed(2)+"</br>"+
							"the salary is $"+salary.toFixed(2)+"</br>";
	 		document.getElementById("showIncome").innerHTML=message;
		}	
	}
}