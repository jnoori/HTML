var userCountry= prompt("Please enter your country name");
switch (userCountry){
	case "japan":
		document.location.href = "index-japan.html";
		break;
	case "brazi":
		document.location.href = "index-brazi.html";
		break;
	case "iran":
		document.location.href = "index-iran.html";
		break;
}
function currencyExchange(){
	var iranRate =0.0000319966;
	var usRate=1.34716;
	var euroRate=1.51323;
	var poundRate=1.74526;
	var AUDRate=0.935720;
	var AEDRate=0.366811;
	var BRLRate=0.338338;
	var JPYRate=0.0123427;
	var CHFRate=1.33845;
	var CNYRate=0.195847;
	var cad=0;
	var userInput= document.getElementById("amount").value;
	//var currencyFrom = document.getElementById("currencyFrom").value;
	var currencyFrom = document.getElementsByClassName("dropdown-item").value;
	var currencyTo = document.getElementById("currencyTo").value;
	var result=0
	var regex=/^[0-9]+$/;
	if (userInput != null && userInput.match(regex) && userInput>=0){
		switch (currencyFrom){
			case "iran":
				cad= userInput*iranRate;
				break;
			case "usa":
				cad= userInput*usRate;
				break;
			case "europe":
				cad= userInput*euroRate;
				break;
			case "britain":
				cad= userInput*poundRate;
				break;
			case "australia":
				cad= userInput*AUDRate;
				break;
			case "emirate":
				cad= userInput*AEDRate;
				break;
			case "brazil":
				cad= userInput*BRLRate;
				break;
				case "japan":
					cad= userInput*JPYRate;
					break;
			case "china":
				cad= userInput*CNYRate;
				break;
			case "swiss":
				cad= userInput*CHFRate;
				break;
		}
		switch (currencyTo){
			case "iran":
				reslut= cad/iranRate;
				break;
			case "usa":
				reslut= cad/usRate;
				break;
			case "europe":
				reslut= cad/euroRate;
				break;
			case "britain":
				reslut= cad/poundRate;
				break;
			case "australia":
				reslut= cad/AUDRate;
				break;
			case "emirate":
				reslut= cad/AEDRate;
				break;
			case "brazil":
				reslut= cad/BRLRate;
				break;
			case "japan":
				reslut= cad/JPYRate;
				break;
			case "china":
				reslut= cad/CNYRate;
				break;
			case "swiss":
				reslut= cad/CHFRate;
				break;
		}
		document.getElementById("result").innerHTML=result;
	}

}
function changeFromIran(){
	document.getElementById("dropdownMenuOffset").innerHTML="Iranian Rials (IRR)"
}